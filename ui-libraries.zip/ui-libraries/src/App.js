
import './App.css';
import Footer from './component/Footer.js';
import Home from './component/Home.js';
import Navbar from "./component/Navbar.js";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Home/>
     <Footer/>
    </div>
  );
}

export default App;
