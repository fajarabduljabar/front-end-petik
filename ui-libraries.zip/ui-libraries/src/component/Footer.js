import React from 'react'

const Footer = () => {
  return (
    <div>
      <footer>
        <h3>Copyright &copy; 2024 Develoved by Fajar Abdul Jabar</h3>
        <span>Make with &#10084;</span>
      </footer>
    </div>
  )
}

export default Footer
